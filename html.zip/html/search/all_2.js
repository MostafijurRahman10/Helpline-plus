var searchData=
[
  ['dashboard_2ephp_13',['dashboard.php',['../dashboard_8php.html',1,'']]],
  ['doctor_2ephp_14',['doctor.php',['../doctor_8php.html',1,'']]]
];
