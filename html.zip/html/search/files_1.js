var searchData=
[
  ['dashboard_2ephp_28',['dashboard.php',['../dashboard_8php.html',1,'']]],
  ['doctor_2ephp_29',['doctor.php',['../doctor_8php.html',1,'']]]
];
