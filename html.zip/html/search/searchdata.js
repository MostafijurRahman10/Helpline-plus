var indexSectionsWithContent =
{
  0: "$bdefhirsu",
  1: "bdfhirsu",
  2: "$ei",
  3: "h"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "variables",
  3: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Variables",
  3: "Pages"
};

