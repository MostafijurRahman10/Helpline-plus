var searchData=
[
  ['_24_5fsession_0',['$_SESSION',['../index_8php.html#a5f545b9684799a00f7a14442205b98e3',1,'index.php']]],
  ['_24allposts_1',['$allPosts',['../dashboard_8php.html#ae2ee8ca8da7538f5882519b75971e8ee',1,'dashboard.php']]],
  ['_24db_2',['$db',['../index_8php.html#a1fa3127fc82f96b1436d871ef02be319',1,'$db():&#160;index.php'],['../register_8php.html#a1fa3127fc82f96b1436d871ef02be319',1,'$db():&#160;register.php'],['../session_8php.html#a1fa3127fc82f96b1436d871ef02be319',1,'$db():&#160;session.php']]],
  ['_24email_3',['$email',['../user_8php.html#a32027f7b9fb6904cb5d7040d7b660060',1,'user.php']]],
  ['_24filename_4',['$fileName',['../session_8php.html#a68fbc5a9273a24181c50a057d11603fa',1,'session.php']]],
  ['_24flag_5',['$flag',['../dashboard_8php.html#acf5d6dd3ee125abb9a2523b30bc47d02',1,'$flag():&#160;dashboard.php'],['../index_8php.html#acf5d6dd3ee125abb9a2523b30bc47d02',1,'$flag():&#160;index.php'],['../register_8php.html#acf5d6dd3ee125abb9a2523b30bc47d02',1,'$flag():&#160;register.php']]],
  ['_24imgflag_6',['$imgflag',['../settings_8php.html#a0c3d15e3c8c6894cfb133f1be66e6193',1,'settings.php']]],
  ['_24name_7',['$name',['../session_8php.html#ab2fc40d43824ea3e1ce5d86dee0d763b',1,'session.php']]],
  ['_24passflagdemo_8',['$passFlagDemo',['../settings_8php.html#af9f7a32112616c0d61dbcb7ec254bd4f',1,'settings.php']]],
  ['_24res_9',['$res',['../user_8php.html#a49a8a4009b02e49717caa88b128affc5',1,'user.php']]],
  ['_24title_10',['$title',['../session_8php.html#ada57e7bb7c152edad18fe2f166188691',1,'session.php']]],
  ['_24updateflag_11',['$updateFlag',['../user_8php.html#a5aeca86e823982be553f413b95e3b68f',1,'user.php']]]
];
