var searchData=
[
  ['if_19',['if',['../register_8php.html#a0d1b7ba88b0f4705c67fcbd4c38c9c5c',1,'if():&#160;register.php'],['../session_8php.html#ad0b3d51a911e55de6c3395c8549237d1',1,'if():&#160;session.php'],['../settings_8php.html#a0e26096d7fba554ecd47dde23c4d407c',1,'if():&#160;settings.php'],['../user_8php.html#a9db1af915cde95754eef39d9d58e8f14',1,'if():&#160;user.php']]],
  ['index_2ephp_20',['index.php',['../index_8php.html',1,'']]]
];
